package ch.wiss.m223_starter.security;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import ch.wiss.m223_starter.model.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * maps our custom user 
 */
@Setter @Getter @AllArgsConstructor
public class UserDetailsImpl implements UserDetails {
    private static final long serialVersionUID = 1L;

    private Long id;  
    private String username;  
    private String email;
  
    @JsonIgnore
    private String password;
  
    private Collection<? extends GrantedAuthority> authorities;
  
    public static UserDetailsImpl build(User user) {
      List<GrantedAuthority> authorities = user.getRoles()
        .stream()
        .map(role -> new SimpleGrantedAuthority(role.toString()))
        .collect(Collectors.toList());
  
      return new UserDetailsImpl(
          (long)user.getId(), 
          user.getUsername(), 
          user.getEmail(),
          user.getPassword(), 
          authorities);
    }

    @Override
    public boolean isAccountNonExpired() { return true;   }
  
    @Override
    public boolean isAccountNonLocked() { return true;   }
  
    @Override
    public boolean isCredentialsNonExpired() {  return true;   }
  
    @Override
    public boolean isEnabled() {   return true;   }
  
    @Override
    public boolean equals(Object o) {
      if (this == o)     return true;
      if (o == null || getClass() != o.getClass()) return false;
      UserDetailsImpl user = (UserDetailsImpl) o;
      return Objects.equals(id, user.id);
    }
}