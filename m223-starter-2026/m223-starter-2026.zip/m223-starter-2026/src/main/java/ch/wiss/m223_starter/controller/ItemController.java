package ch.wiss.m223_starter.controller;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import ch.wiss.m223_starter.model.Item;
import ch.wiss.m223_starter.repository.ItemRepository;

@Controller
@RequestMapping("/items")
public class ItemController {

    @Autowired
    private ItemRepository itemRepository;

    @GetMapping("/")
    public ResponseEntity<List<Item>> getItems(){
        List<Item> result = itemRepository.findAll();
        return ResponseEntity.ok(result);
    }
    
}
