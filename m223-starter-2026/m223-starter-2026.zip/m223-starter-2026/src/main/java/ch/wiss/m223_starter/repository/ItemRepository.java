package ch.wiss.m223_starter.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ch.wiss.m223_starter.model.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
    
}
